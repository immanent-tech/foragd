package main

import (
	"context"
	"log/slog"
	"net/url"
	"slices"

	slogctx "github.com/veqryn/slog-context"

	"github.com/immanent-tech/go-base/logging"

	"github.com/immanent-tech/foragd/models"
	"github.com/immanent-tech/foragd/providers/elastic"
	"github.com/immanent-tech/foragd/providers/elastic/bulk"
	"github.com/immanent-tech/foragd/providers/elastic/query"
	"github.com/immanent-tech/foragd/service"
)

func main() {
	ctx := slogctx.NewCtx(context.Background(), logging.New())

	if err := elastic.Connect(); err != nil {
		panic(err)
	}

	elasticSvc, err := service.LoadElasticService()
	if err != nil {
		panic(err)
	}

	slogctx.FromCtx(ctx).Info("Get all feeds.")
	feeds, err := elastic.SearchAll[*models.Feed](
		ctx,
		elasticSvc.GetIndexRO(service.FeedsIndex),
		query.MatchAll(),
		5000,
	)
	if err != nil {
		panic(err)
	}

	slogctx.FromCtx(ctx).Info("Update feeds to add domains.")
	for feed := range slices.Values(feeds) {
		if feed.Domain != "" {
			continue
		}
		link, err := url.Parse(feed.GetLink())
		if err == nil && (link.Hostname() != "" && link.IsAbs()) {
			feed.Domain = link.Hostname()
		} else {
			link, err := url.Parse(feed.GetSourceURLs()[0])
			if err != nil {
				slogctx.Warn(ctx, "Failed to parse feed link.",
					slog.String("link", feed.GetLink()),
					slog.Any("error", err))
				continue
			}
			feed.Domain = link.Hostname()
		}
		slogctx.Info(ctx, "Added domain to feed.",
			slog.String("feed_id", feed.GetID()),
			slog.String("feed_title", feed.GetTitle()),
			slog.String("domain", feed.Domain))
	}

	if err := bulk.IndexDocuments(ctx, elasticSvc.GetIndexRW(service.FeedsIndex), feeds...); err != nil {
		panic(err)
	}
}
